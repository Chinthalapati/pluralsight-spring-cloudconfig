package com.bhanusri.springboot.service.model;

import com.bhanusri.springboot.service.interfaces.Param;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParamsObject implements Param {

	@JsonProperty(required=true)
	private MessageEncoding messageEncoding;
	
	@JsonProperty(required=true)
	private String param;
	
	@JsonProperty(required=true)
	private String value;
	
	public MessageEncoding getMessageEncoding() {
		if(messageEncoding == null) 
			messageEncoding = MessageEncoding.NONE;
		return messageEncoding;
	}

	public void setMessageEncoding(MessageEncoding messageEncoding) {
		this.messageEncoding = messageEncoding;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
	
	
}
