package com.bhanusri.springboot.service.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Params {
	
	@JsonProperty(required=true)
	private String payload;
	
	@JsonProperty(required=true)
	private List<ParamsObject> params;
	
	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public List<ParamsObject> getParams() {
		return params;
	}

	public void setParams(List<ParamsObject> params) {
		this.params = params;
	}
}
