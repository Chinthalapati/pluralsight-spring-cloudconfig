package com.bhanusri.springboot.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XsltTransformerApplication {

	public static void main(String[] args) {
		SpringApplication.run(XsltTransformerApplication.class, args);
	}
}
