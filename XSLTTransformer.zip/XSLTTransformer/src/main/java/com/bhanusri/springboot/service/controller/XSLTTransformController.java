package com.bhanusri.springboot.service.controller;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.boot.context.config.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.bhanusri.springboot.service.model.Params;
import com.bhanusri.springboot.service.model.ParamsObject;
import com.bhanusri.springboot.service.model.XQueryObject;
import com.bhanusri.springboot.service.model.XQueryParams;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value="Transformer Service")
public class XSLTTransformController {

	@ApiOperation(value="Transform the given payload using XSLT from classpath resource", response = String.class)
	@ApiResponses(value = {
			@ApiResponse ( code = 200, message = "Transformed Successfully"),
			@ApiResponse ( code = 500, message = "Internal Server Error"),
			@ApiResponse ( code = 404, message = "Resource not found!."), 
			})
	@PostMapping(value = "/transform/xslt/resource" ,produces = {"application/xml", "text/xml" })
	public ResponseEntity<?> transformUsingXSLT(@RequestBody Params params /*, @RequestPart(value="xsltFile") MultipartFile attachment */) throws Throwable {
		
		 try {
			 
			 TransformerFactory tFactory = TransformerFactory.newInstance();
		   
		   // Use the TransformerFactory to process the stylesheet source and produce a Transformer 
		   //StreamSource styleSource = new StreamSource(attachment.getInputStream());
			 FileInputStream fis = new FileInputStream("src/main/resources/xml/input.xsl");
			// StreamSource styleSource = new StreamSource(attachment.getInputStream());
			 StreamSource styleSource = new StreamSource(fis);
			 Transformer transformer = tFactory.newTransformer(styleSource);
		   
		   // Use the transformer and perform the transformation
			 StreamSource xmlSource = new StreamSource(new ByteArrayInputStream(Base64.decodeBase64(params.getPayload())));
			 StringWriter result = new StringWriter();
		   
			// String xmlString = new String("<params><param><key>//catalog/book/genre</key><value>History</value></param></params>");
			 StringBuffer xmlString = new StringBuffer();
			 xmlString.append("<params>");
			 for(ParamsObject param : params.getParams()) {
				 xmlString.append("<param><key>" + param.getParam() + "</key><value>" + param.getValue() + "</value></param>");
			 }
			 xmlString.append("</params>");
			
			 // System.out.println(xmlString);
			 Element node =  DocumentBuilderFactory
				    .newInstance()
				    .newDocumentBuilder()
				    .parse(new ByteArrayInputStream(xmlString.toString().getBytes()))
				    .getDocumentElement();
		 
			 transformer.setParameter("xmlDoc", node);
		   
			 // transformer.setParameter("xmlDoc1", xmlString);
			 transformer.transform(xmlSource, new StreamResult(result));
			 
		   return new ResponseEntity<Object>(result.toString(),HttpStatus.OK);
		  	  } 
		 catch (ResourceNotFoundException e)
	  		{
	  		  	e.printStackTrace();
	  		  	return new ResponseEntity<Object>("XSLT File not found under resources!", HttpStatus.NOT_FOUND);
	  		}
		 catch (Exception e)
		  		{
		  		  	e.printStackTrace();
		  		  	return new ResponseEntity<Object>("Some other error!!!", HttpStatus.BAD_REQUEST);
		  		}
		}
	
	
	
	@ApiOperation(value="Transform the given payload using XSLT from attachment.", response = String.class)
	@ApiResponses(value = {
			@ApiResponse ( code = 200, message = "Transformed Successfully"),
			@ApiResponse ( code = 500, message = "Internal Server Error"),
			@ApiResponse ( code = 404, message = "Resource not found!."), 
			})
	@PostMapping(value = "/transform/xslt/attach" ,produces = {"application/xml", "text/xml" })
	public ResponseEntity<?> transformUsingAttached(@RequestPart String jsonParams , @RequestPart(value="xsltFile") MultipartFile attachment) throws Throwable {
		
		 try {
			 
			 TransformerFactory tFactory = TransformerFactory.newInstance();
		   
			 ObjectMapper mapper = new ObjectMapper();
			// HashMap<String,String> params =  mapper.readValue(jsonParams, new TypeReference<HashMap<String,String>>(){});
			 Params params = mapper.readValue(jsonParams, Params.class);
			 System.out.println(params);
		   // Use the TransformerFactory to process the stylesheet source and produce a Transformer 
		   StreamSource styleSource = new StreamSource(attachment.getInputStream());
			 //FileInputStream fis = new FileInputStream("src/main/resources/xml/input.xsl");
			// StreamSource styleSource = new StreamSource(attachment.getInputStream());
			 //StreamSource styleSource = new StreamSource(fis);
			 Transformer transformer = tFactory.newTransformer(styleSource);
		   
		   // Use the transformer and perform the transformation
			 StreamSource xmlSource = new StreamSource(new ByteArrayInputStream(Base64.decodeBase64(params.getPayload())));
			 StringWriter result = new StringWriter();
		   System.out.println("XSLT File : "  + styleSource.toString());
		   System.out.println(xmlSource.toString());
			// String xmlString = new String("<params><param><key>//catalog/book/genre</key><value>History</value></param></params>");
			 StringBuffer xmlString = new StringBuffer();
			 xmlString.append("<params>");
			 for(ParamsObject param : params.getParams()) {
				 xmlString.append("<param><key>" + param.getParam() + "</key><value>" + param.getValue() + "</value></param>");
			 }
			 xmlString.append("</params>");
			
			 // System.out.println(xmlString);
			 Element node =  DocumentBuilderFactory
				    .newInstance()
				    .newDocumentBuilder()
				    .parse(new ByteArrayInputStream(xmlString.toString().getBytes()))
				    .getDocumentElement();
		 
			 transformer.setParameter("xmlDoc", node);
		   
			 // transformer.setParameter("xmlDoc1", xmlString);
			 transformer.transform(xmlSource, new StreamResult(result));
			 
		   return new ResponseEntity<Object>(result.toString(),HttpStatus.OK);
		  	  } 
		 catch (ResourceNotFoundException e)
	  		{
	  		  	e.printStackTrace();
	  		  	return new ResponseEntity<Object>("XSLT File not attached!", HttpStatus.NOT_FOUND);
	  		}
		 catch (Exception e)
		  		{
		  		  	e.printStackTrace();
		  		  	return new ResponseEntity<Object>("Some other error!!!", HttpStatus.BAD_REQUEST);
		  		}
		}


	@ApiOperation(value="Transform the given payload using XSLT from classpath resource", response = String.class)
	@ApiResponses(value = {
			@ApiResponse ( code = 200, message = "Transformed Successfully"),
			@ApiResponse ( code = 500, message = "Internal Server Error"),
			@ApiResponse ( code = 404, message = "Resource not found!."), 
			})
	@PostMapping(value = "/xquery" ,produces = {"application/json","text/xml" })
	public ResponseEntity<?> queryXML(@RequestBody XQueryParams xquery) throws Throwable {
		
		 try {
			 
			 TransformerFactory tFactory = TransformerFactory.newInstance();
			 FileInputStream fis = new FileInputStream("src/main/resources/xml/xquery.xsl");

			 StreamSource styleSource = new StreamSource(fis);
			 Transformer transformer = tFactory.newTransformer(styleSource);
		   
		   // Use the transformer and perform the transformation
			 StreamSource xmlSource = new StreamSource(new ByteArrayInputStream(Base64.decodeBase64(xquery.getPayload())));
			 StringWriter result = new StringWriter();
		   
			
			 StringBuffer xmlString = new StringBuffer();
			 xmlString.append("<params>");
			 for(XQueryObject param : xquery.getParams()) {
				 xmlString.append("<param><item>" + param.getParam() + "</item></param>");
			 }
			 xmlString.append("</params>");
			
			 System.out.println(xmlString.toString());
			 // System.out.println(xmlString);
			 Element node =  DocumentBuilderFactory
				    .newInstance()
				    .newDocumentBuilder()
				    .parse(new ByteArrayInputStream(xmlString.toString().getBytes()))
				    .getDocumentElement();
		 
			 transformer.setParameter("paramsArray", node);
		   
			 // transformer.setParameter("xmlDoc1", xmlString);
			 transformer.transform(xmlSource, new StreamResult(result));
			 
			 String[] keyValuePairs = result.toString().split("\n");              //split the string to creat key-value pairs
			 Map<String,String> map = new HashMap<>();               

			 for(String pair : keyValuePairs)                        //iterate over the pairs
			 {
			     String[] entry = pair.split("§");                   //split the pairs to get key and value 
			     map.put(entry[0].trim(), entry[1].trim());          //add them to the hashmap and trim whitespaces
			 }
			 
			/* System.out.println("<output>" + result.toString() + "</output>");
			 Document doc = DocumentBuilderFactory.newInstance()
                     .newDocumentBuilder()
                     .parse(new InputSource(new StringReader("<output>" + result.toString() + "</output>")));
			 */
		   return new ResponseEntity<Object>(map,HttpStatus.OK);
		  	  } 
		 catch (ResourceNotFoundException e)
	  		{
	  		  	e.printStackTrace();
	  		  	return new ResponseEntity<Object>("XSLT File not found under resources!", HttpStatus.NOT_FOUND);
	  		}
		 catch (Exception e)
		  		{
		  		  	e.printStackTrace();
		  		  	return new ResponseEntity<Object>("Some other error!!!", HttpStatus.BAD_REQUEST);
		  		}
		}
	
}
