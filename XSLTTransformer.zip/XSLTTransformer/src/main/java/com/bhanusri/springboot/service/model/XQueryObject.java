package com.bhanusri.springboot.service.model;
import com.bhanusri.springboot.service.interfaces.XQuery;
import com.fasterxml.jackson.annotation.JsonProperty;

public class XQueryObject implements XQuery {

	@JsonProperty(required=true)
	private MessageEncoding messageEncoding;
	
	@JsonProperty(required=true)
	private String param;
	
	public MessageEncoding getMessageEncoding() {
		if(messageEncoding == null) 
			messageEncoding = MessageEncoding.NONE;
		return messageEncoding;
	}

	public void setMessageEncoding(MessageEncoding messageEncoding) {
		this.messageEncoding = messageEncoding;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}	
	
	
}
