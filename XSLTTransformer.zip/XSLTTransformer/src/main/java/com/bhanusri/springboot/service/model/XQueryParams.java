package com.bhanusri.springboot.service.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class XQueryParams {
	
	@JsonProperty(required=true)
	private String payload;
	
	@JsonProperty(required=true)
	private List<XQueryObject> params;
	
	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public List<XQueryObject> getParams() {
		return params;
	}

	public void setParams(List<XQueryObject> params) {
		this.params = params;
	}
}
