package com.bhanusri.springboot.service.interfaces;

public interface Param {
	enum MessageEncoding {
		BASE64, NONE
	}
}
